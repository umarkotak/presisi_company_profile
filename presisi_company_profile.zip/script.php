<script type="text/javascript" src="style/js1.js"></script>
<script type="text/javascript" src="style/js2.js"></script>

<script type="text/javascript">
  var $zoho= $zoho || {salesiq:{values:{},ready:function(){}}};var d=document;s=d.createElement("script");s.type="text/javascript";
  s.defer=true;s.src="style/js3.js";
  t=d.getElementsByTagName("script")[0];t.parentNode.insertBefore(s,t);
  $zoho.salesiq.ready=function(embedinfo){$zoho.salesiq.floatbutton.visible("hide");}
</script>

<!-- <script type="text/javascript">
  var $zoho= $zoho || {salesiq:{values:{},ready:function(){}}};var d=document;s=d.createElement("script");s.type="text/javascript";
  s.defer=true;s.src="style/js4.js";
  t=d.getElementsByTagName("script")[0];t.parentNode.insertBefore(s,t);
</script> -->

<!-- <script type="text/javascript">
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
    (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
    m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-26369507-1', 'auto');
  ga('send', 'pageview');
</script> -->

<!-- <script type="text/javascript">
  var leady_track_key="XSnB2eIcJpnvA8mH";
  var leady_track_server=document.location.protocol+"//t.leady.cz/";
  (function(){
    var l=document.createElement("script");l.type="text/javascript";l.async=true;
    l.src=leady_track_server+leady_track_key+"/L.js";
    var s=document.getElementsByTagName("script")[0];s.parentNode.insertBefore(l,s);
  })();
</script> -->