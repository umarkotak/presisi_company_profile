<section class="contetnt">
	<div class="row">
		<div class="col-xs-12">
			<div class="box">
				<div class="box-header with-border">
					<h3 class="box-title">Home</h3>
				</div>
				<div class="box-body">
					<p>Welcome to the administrator page. <br>Use the features available on this page to improve the quality of service.</p>
				</div>
				<div class="box-footer clearfix">
					<a href="?show=logout" class="btn btn-warning">Sign out</a>
				</div>
			</div>
		</div>
	</div>
</section>