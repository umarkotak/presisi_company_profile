<head>
  <!-- <meta http-equiv="content-type" content="text/html; charset=utf-8">
  <meta http-equiv="content-language" content="en">
  <meta name="copyright" content="2016-2018">
  <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"> -->

  <meta name="description" content="Your trusted partner for logistics and supply chain needs" />

  <title>PT Presisi Rekayasa</title>

  <link rel="shortcut icon" href="images/favicon.ico">

  <link rel="stylesheet" type="text/css" href="style/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="style/css1.css" />
  <link rel="stylesheet" type="text/css" href="style/css2.css" />
  <!-- <link rel="stylesheet" type="text/css" href="style/custom-font.css"> -->
  <link rel="stylesheet" type="text/css" href="style/presisi.css">

<!--   <script type="text/javascript">
  /* <![CDATA[ */
  $(function() {new NNewsAjax("", "stranka", {"disableAjaxOnFirstPage":1,"summarytemplate":"HP - P3Live","category":"EN | P3 live | Press-Releases","detailpage":"blogs","number":3,"module":"News","action":"default","deliminer":"","show_page_numbers":true,"lang":"","returnid":"2","alias":"home"})});
  /* ]]> */
  </script> -->
</head>
