<footer class="container-fluid op-0">
  <div class="row">
    <div class="col-xs-12 col-sm-12">
      <p style="font-size: 15px; color: #002699; text-align: center;"><b>Copyright &copy; </b>PT. Presisi Rekayasa Persada, 2018. All Rights Reserved.</p>
    </div>
    <div class="col-xs-12 col-sm-12 t-right">

    </div>
  </div>
</footer>