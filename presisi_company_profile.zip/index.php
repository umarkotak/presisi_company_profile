<?php session_start(); ?>
<?php include "config.php"; ?>

<!DOCTYPE html>
<html>

<?php include "head.php"; ?>

<body>

<?php include "header.php"; ?>
<?php include "content.php"; ?>
<?php include "footer.php"; ?>
<?php include "script.php"; ?>

</body>
</html>