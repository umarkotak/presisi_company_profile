# Presisi Company Profile #

---

### Work Guide ###

1. Lakukan ```git pull origin master``` sebelum melanjutkan pekerjaan
2. Lakukan ```git push origin master``` ketika semua pekerjaan telah beres

*note : hot to git
1. ```git add -A```
2. ```git commit -m "komentar"```